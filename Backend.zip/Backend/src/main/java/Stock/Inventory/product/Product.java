package Stock.Inventory.product;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.util.Date;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Attributes
    @Column( unique = true)
    private long productId; // Unique identifier for the product

    @NotBlank(message = "Product name cannot be blank")
    @Column( nullable = false, unique = true)
    private String productName; // Name or description of the product


    @DateTimeFormat(pattern="yyyy-MM-dd")
    private LocalDate expiryDate = LocalDate.now().plusMonths(3); // Date when the product expires

    @DateTimeFormat(pattern="yyyy-MM-dd")
    private LocalDate timeDurationForMarkDown; // Duration before expiry for markdown (in days)

    @Column(name = "min_threshold")
    private Integer minThreshold = 0;

    @Column(name= "quantity")
    private Integer quantity = 0;


    @Column(name = "max_threshold")
    private Integer maxThreshold = 0;

    // Constructors


    public Product() {
    }

    public Product(String productName, LocalDate expiryDate, LocalDate timeDurationForMarkDown, Integer minThreshold, Integer quantity, Integer maxThreshold) {
        this.productName = productName;
        this.expiryDate = expiryDate;
        this.timeDurationForMarkDown = timeDurationForMarkDown;
        this.minThreshold = minThreshold;
        this.quantity = quantity;
        this.maxThreshold = maxThreshold;
    }

// Getters and Setters


    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public LocalDate getTimeDurationForMarkDown() {
        return timeDurationForMarkDown;
    }

    public void setTimeDurationForMarkDown(LocalDate timeDurationForMarkDown) {
        this.timeDurationForMarkDown = timeDurationForMarkDown;
    }

    public Integer getMinThreshold() {
        return minThreshold;
    }

    public void setMinThreshold(Integer minThreshold) {
        this.minThreshold = minThreshold;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getMaxThreshold() {
        return maxThreshold;
    }

    public void setMaxThreshold(Integer maxThreshold) {
        this.maxThreshold = maxThreshold;
    }
}
