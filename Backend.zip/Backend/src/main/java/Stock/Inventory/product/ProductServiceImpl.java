package Stock.Inventory.product;

import Stock.Inventory.exception.ResourceDuplicateNotFoundException;
import Stock.Inventory.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;


import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepo productRepo; // You would inject your actual repository here


    @Override
    public void deleteProduct(long productId) {

        Product product1 =productRepo.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product does not exist with the ID: " + productId));

        productRepo.delete(product1);

    }



    @Override
    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }

    @Override
    public Product getProductById(long productId) {
        return productRepo.findById(productId).orElseThrow(() -> new ResourceNotFoundException("Product with id: " + productId + " not found."));
    }

    @Override
    public Product getProductByName(String productName) {
        return productRepo.findByProductName(productName).orElseThrow(() -> new ResourceNotFoundException("Product with name: " + productName + " not found."));
    }

    @Override
    public Product addProduct(Product product) {
        try {
            return productRepo.save(product);
        } catch (DataIntegrityViolationException ex) {
            throw new ResourceDuplicateNotFoundException("ProductName should have a uniqueID, the ProductName already exists with the same uniqueID");
        }
    }

    @Override
    public Product updateProduct(long productId, Product product) {
        if (productRepo.existsById(productId)) {
            product.setProductId(productId);
            return productRepo.save(product);
        }
        return null;
    }



    @Override
    public List<String> getReplenishmentInfoForAllProducts() {
        List<Product> products = getAllProducts();
        return products.stream().map(this::getReplenishmentInfo).collect(Collectors.toList());
    }

    @Override
    public String getReplenishmentInfo(Product product) {
        Integer replenishmentQty = calculateReplenishmentQuantity(product);

        if (replenishmentQty > 0) {
            return "Replenish " + replenishmentQty + " " + product.getProductName();
        } else if (replenishmentQty == 0) {
            return "No replenishment needed for " + product.getProductName();
        } else {
            return "Remove " + Math.abs(replenishmentQty) + " " + product.getProductName();
        }
    }

    @Override
    public String getReplenishmentInfo(long productId) {
        Product product = getProductById(productId);
        Integer replenishmentQty = calculateReplenishmentQuantity(product);

        if (replenishmentQty > 0) {
            return "Replenish " + replenishmentQty + " " + product.getProductName();
        } else if (replenishmentQty == 0) {
            return "No replenishment needed for " + product.getProductName();
        } else {
            return "Remove " + Math.abs(replenishmentQty) + " " + product.getProductName();
        }
    }

    @Override
    public Integer calculateReplenishmentQuantity(Product product) {
        int currentQuantity = product.getQuantity();
        int minThreshold = product.getMinThreshold();
        int maxThreshold = product.getMaxThreshold();

        if (currentQuantity < minThreshold) {
            // If current quantity is below the minimum threshold, calculate the replenishment quantity
            return minThreshold - currentQuantity;
        } else if (currentQuantity < maxThreshold) {
            // If current quantity is within the thresholds, no replenishment is needed
            return 0;
        } else {
            return maxThreshold - currentQuantity;
        }
    }

    @Override
    public String getCountInfo(Product product) {
        Integer count = product.getQuantity();
        return "We have " + count + " " + product.getProductName()+ " in stock.";
    }

    @Override
    public List<String> getCountInfoForAllProducts() {
        List<Product> products = getAllProducts();
        return products.stream().map(this::getCountInfo).collect(Collectors.toList());
    }

    @Override
    public String getExpiryDateInfo(Product product) {
        String date = product.getExpiryDate().toString();
        return product.getProductName() + " expires " + date;
    }

    @Override
    public List<String> getExpiryDateInfoForAllProducts() {
        List<Product> products = getAllProducts();
        return products.stream().map(this::getExpiryDateInfo).collect(Collectors.toList());
    }

    @Override
    public Product getExpiredProductInfo(Product product) {
        LocalDate today = LocalDate.now();
        if (product.getExpiryDate().isBefore(today)) {
            return product;
        }
        return null;
    }

    @Override
    public List<Product> getAllExpiredProductInfo() {
        List<Product> products = getAllProducts();
        return products.stream().map(this::getExpiredProductInfo).filter(Objects::nonNull).collect(Collectors.toList());
    }

    @Override
    public Product getProductInMarkdownInfo(Product product) {
        LocalDate today = LocalDate.now();
        if (product.getTimeDurationForMarkDown().isBefore(today)) {
            return product;
        }
        return null;
    }

    @Override
    public List<Product> getAllProductsInMarkdownInfo() {
        List<Product> products = getAllProducts();
        return products.stream().map(this::getProductInMarkdownInfo).filter(Objects::nonNull).collect(Collectors.toList());
    }

    @Override
    public Product getProductForMarkdownInfo(Product product) {
        LocalDate today = LocalDate.now();
        if (product.getTimeDurationForMarkDown().isAfter(today.plusWeeks(1))) {
            return product;
        }
        return null;
    }

    @Override
    public List<Product> getAllProductsForMarkdownInfo() {
        List<Product> products = getAllProducts();
        return products.stream().map(this::getProductForMarkdownInfo).filter(Objects::nonNull).collect(Collectors.toList());
    }
}



