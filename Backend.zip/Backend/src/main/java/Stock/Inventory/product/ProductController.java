package Stock.Inventory.product;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.awt.*;

@Controller
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/cover")
    public String coverPage(Model model) {

        return "cover";
    }
    @GetMapping("/product")
    public String getAllProduct(Model model) {
        model.addAttribute("listProducts", productService.getAllProducts());
        return "product/product_list";
    }

    @GetMapping("/my_products")
    public String getMyProducts(Model model) {
        // create model attribute to bind form data
  Product product=new Product() ;
        model.addAttribute("product", product);
        return "product/new_product";
    }

    @PostMapping("/saveProduct")
    public String saveProduct(@ModelAttribute("product") @Valid Product product,
                           BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "product/new_product";
        }
        // save menu to database
        productService.addProduct(product);
        return "redirect:/product";
    }

    @GetMapping("/my_products/{id}")
    public String getProductsById(@PathVariable(value = "id") long productId, Model model) {
Product product=productService.getProductById(productId);
        model.addAttribute("product", product);

        return "product/update_product";
    }

    @GetMapping("/deleteProduct/{id}")
    public String deleteMenu(@PathVariable(value = "id") long productId) {
        this.productService.deleteProduct(productId);

        return "redirect:/product";
    }

}
