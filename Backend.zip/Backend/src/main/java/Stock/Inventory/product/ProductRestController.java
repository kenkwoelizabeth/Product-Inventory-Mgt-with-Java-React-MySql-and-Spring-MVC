package Stock.Inventory.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.awt.*;
import java.util.List;
import java.util.Optional;


@RestController

@RequestMapping("/api")
public class ProductRestController {

    @Autowired
    private ProductService productService; // Inject the ProductService




    @GetMapping
    public ResponseEntity<List<Product>> getProducts() {
        return new ResponseEntity<>(productService.getAllProducts(), HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable long productId) {
        Product product = productService.getProductById(productId);

        if (product != null) {
            return new ResponseEntity<>(product, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @PostMapping
    public Product addProduct(@Valid @RequestBody Product product) {
        return productService.addProduct(product);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable long productId, @Valid @RequestBody Product product) {
        Product updatedProduct = productService.updateProduct(productId, product);
        return new ResponseEntity<>(updatedProduct, HttpStatus.OK);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable  long productId) {
        productService.deleteProduct(productId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


    //    ROUTES BELOW HERE ARE SPECIFIC REQUIREMENTS FROM A PROJECT SPECIFICATION

    @PostMapping("/create-product")
    public Product createProduct(@Valid @RequestBody Product product) {
        return productService.addProduct(product);
    }


    @GetMapping("/display-product")
    public ResponseEntity<List<Product>> displayProduct(@RequestParam(required = false) String productName, @RequestParam(required = false) Long productId) {
        if (productName != null) {
            Product product = productService.getProductByName(productName);
            return new ResponseEntity<>(List.of(product), HttpStatus.OK);
        } else if (productId != null) {
            Product product = productService.getProductById(productId);
            return new ResponseEntity<>(List.of(product), HttpStatus.OK);
        }

        return new ResponseEntity<>(productService.getAllProducts(), HttpStatus.OK);
    }


    @GetMapping("/display-product-to-refill")
    public List<String> displayProductToRefill(@RequestParam(required = false) Long productId) {
        if (productId != null) {
            return List.of(productService.getReplenishmentInfo(productId));
        }
        return productService.getReplenishmentInfoForAllProducts();
    }


    @GetMapping("/display-product-count")
    public List<String> displayProductCount(@RequestParam(required = false) Long productId) {
        if (productId != null) {
            Product product = productService.getProductById(productId);
            return List.of(productService.getCountInfo(product));
        }
        return productService.getCountInfoForAllProducts();
    }


    @GetMapping("/display-products-expiry-date")
    public List<String> displayProductsExpiryDate(@RequestParam(required = false) Long productId) {
        if (productId != null) {
            Product product = productService.getProductById(productId);
            return List.of(productService.getExpiryDateInfo(product));
        }
        return productService.getExpiryDateInfoForAllProducts();
    }


    @GetMapping("/display-expired-products")
    public List<Product> displayExpiredProducts() {
        return productService.getAllExpiredProductInfo();
    }


    @GetMapping("/display-products-in-markdown")
    public List<Product> displayProductsInMarkdown() {
        return productService.getAllProductsInMarkdownInfo();
    }


    @GetMapping("/display-products-for-markdown")
    public List<Product> displayProductsForMarkdown() {
        return productService.getAllProductsForMarkdownInfo();
    }
}







