package Stock.Inventory.product;

import org.springframework.stereotype.Service;

import java.awt.*;
import java.util.List;
import java.util.Optional;

@Service
public interface ProductService {
    public Product addProduct(Product product);

    public List<Product> getAllProducts();

    public Product getProductById(long productId);


    public Product updateProduct(long productId, Product product);

    public void deleteProduct(long productId);




    Product getProductByName(String productName);




    List<String> getReplenishmentInfoForAllProducts();

    String getReplenishmentInfo(Product product);


    String getReplenishmentInfo(long productId);

    Integer calculateReplenishmentQuantity(Product product);

    String getCountInfo(Product product);

    List<String> getCountInfoForAllProducts();

    String getExpiryDateInfo(Product product);

    List<String> getExpiryDateInfoForAllProducts();

    Product getExpiredProductInfo(Product product);

    List<Product> getAllExpiredProductInfo();

    Product getProductInMarkdownInfo(Product product);

    List<Product> getAllProductsInMarkdownInfo();

    Product getProductForMarkdownInfo(Product product);

    List<Product> getAllProductsForMarkdownInfo();
}


