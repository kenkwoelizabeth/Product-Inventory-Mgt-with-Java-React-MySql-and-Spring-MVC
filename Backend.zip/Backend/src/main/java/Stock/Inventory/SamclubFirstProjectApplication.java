package Stock.Inventory;

import Stock.Inventory.product.ProductService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication

public class SamclubFirstProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SamclubFirstProjectApplication.class, args);


    }

    // defining a bean
    @Bean
    public CommandLineRunner commandLineRunner(ProductService productService) {
        return args -> System.out.println("My application got started!!");
    }
}